// ==========================================================
// ✅ BANNER BOT
// ==========================================================
console.clear();
console.log(`
╔══════════════════════════════════════════════════╗
║ 🚀 Cloudflare Pointing Bot - Riswan Store
║                                                    
║ 🌟 Solusi Cerdas untuk Manajemen Domain Anda        
║ ⚡ Super Cepat • 💯 Andal • 🔐 Keamanan Terjamin       
║                                                    
║ 💼 Didesain untuk Profesional, Cocok untuk Semua    
║ 🌍 Global Network, Performa Lokal Terbaik           
║ 📡 Otomatis, Efisien, dan Siap Pakai!               
║                                                    
║ ✅ Bot Aktif dan Siap Melayani Anda!                
║ 🔥 Powered by Riswan Store 2023 Tasikmalaya         
╚══════════════════════════════════════════════════╝
`);
// ==========================================================
// ✅ 1. LOAD MODULE & KONFIGURASI DASAR
// ==========================================================
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs');
const dayjs = require('dayjs');

// Fungsi simpan file JSON
function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

const userState = {}; // Menyimpan status user

// Masukkan token bot dan ID admin
const token = '8108896984:AAHdfuQrPBoSBMK_K7fpixlkVQfYg65uQOc'; // Ganti dengan token asli dari BotFather
const ADMIN_ID = 7545471466;
const bot = new TelegramBot(token, { polling: true });
const adminId = ADMIN_ID;

// ✅ Konfigurasi GitHub
const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub kamu
const REPO_OWNER = 'script-vpn-premium'; // ✅ sesuai nama pemilik repo
const REPO_NAME = 'vip';                 // ✅ sesuai nama repo
const FILE_PATH = 'REGIST';              // ✅ nama file
const BRANCH = 'main';

// File lokal
const userFile = './users.json';
const domainFile = './cloudflare_accounts.json';
const cfAccountsFile = './cloudflare_accounts.json';

if (!fs.existsSync(userFile)) fs.writeFileSync(userFile, '[]');
if (!fs.existsSync(domainFile)) fs.writeFileSync(domainFile, '[]');
if (!fs.existsSync(cfAccountsFile)) fs.writeFileSync(cfAccountsFile, '{}');

// ✅ Backup file
function backupFile(filePath, caption, chatId) {
  if (!fs.existsSync(filePath)) {
    bot.sendMessage(chatId, '❌ File tidak ditemukan.');
    return;
  }
  bot.sendDocument(chatId, filePath, { caption });
}
module.exports = { backupFile };

// ==========================================================
// ✅ UTILITAS
// ==========================================================
function saveUser(user) {
  const users = JSON.parse(fs.readFileSync(userFile));
  if (!users.find(u => u.id === user.id)) {
    users.push({
      id: user.id,
      username: user.username || '-',
      first_name: user.first_name || '-'
    });
    fs.writeFileSync(userFile, JSON.stringify(users, null, 2));
  }
  return users.length;
}

function getName(user) {
  return user.first_name || user.username || 'Pengguna';
}

async function isUserJoinedAll(userId) {
  try {
    const channelMember = await bot.getChatMember(requiredChannel, userId);
    const groupMember = await bot.getChatMember(requiredGroup, userId);

    const isInChannel = !['left', 'kicked'].includes(channelMember.status);
    const isInGroup = !['left', 'kicked'].includes(groupMember.status);

    return isInChannel && isInGroup;
  } catch (error) {
    console.error('❌ Gagal cek keanggotaan:', error.message);
    return false;
  }
}

// ✅ Fungsi untuk mengambil total jumlah IP VPS dari GitHub
async function getTotalRegisteredIPs() {
  try {
    const response = await axios.get(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/${BRANCH}/${FILE_PATH}`, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`
      }
    });
    const data = response.data.trim();
    if (!data) return 0;
    const lines = data.split('\n').filter(line => line.trim() !== '');
    return lines.length;
  } catch (error) {
    console.error('❌ Gagal mengambil data REGIST:', error.message);
    return 0;
  }
}

// ==========================================================
// ✅ /start Command
// ==========================================================
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;
  await showStartMenu(chatId, user);
});

// ==========================================================
// ✅ Tampilan Menu Awal
// ==========================================================
async function showStartMenu(chatId, user) {
  try {
    const userId = user.id;
    const name = getName(user);
    const totalUsers = saveUser(user);
    const cfAccounts = JSON.parse(fs.readFileSync(cfAccountsFile));
    const totalCfAccounts = Object.keys(cfAccounts).length;
    const totalIPs = await getTotalRegisteredIPs(); // ✅ Tambahan IP VPS

    const keyboard = [
  [
    { text: '🌐 Pointing', callback_data: 'start_pointing' },
    { text: '💸 Donasi', callback_data: 'donate' }
  ],
  [
    { text: '🔓 Logout', callback_data: 'logout_cf' },
    { text: '📁 Akun', callback_data: 'my_cf_account' }
  ],
  [
    { text: '🔑 Login CF', callback_data: 'login_cf' }
  ],
  [
    { text: '➕ Regis Script', callback_data: 'regist_ip' },
    { text: '🧪 Trial Script', callback_data: 'trial_ip' }
  ],
  [
    { text: '🧹 Hapus IP', callback_data: 'delete_ip_entry' },
    { text: '🚫 Reset IP', callback_data: 'delete_all_ips' }
  ],
  [
    { text: '📄 List IP', callback_data: 'list_ip' }
  ]
];
    bot.sendPhoto(chatId, 'https://files.catbox.moe/ms1z7o.jpg', {
      caption: `\`\`\`
➡️ Total Member       : ${totalUsers} 
➡️ Akun Cloudflare    : ${totalCfAccounts} 
➡️ IP VPS Terdaftar   : ${totalIPs} 
➡️ Sewa Script Tunnel : Rp 8000=1Bulan\`\`\`
`.trim(),
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch (error) {
    console.error('❌ showStartMenu error:', error.message);
    bot.sendMessage(chatId, 'Terjadi kesalahan saat memuat menu.');
  }
}
// ==========================================================
// ✅ 2. CALLBACK HANDLER (TOMBOL)
// ==========================================================
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;
  const userId = query.from.id;

  userState[userId] = data;

  // === Tombol Registrasi IP Premium ===
  if (data === 'regist_ip') {
    if (userId !== adminId) {
      return bot.sendMessage(chatId, `❌ Hanya admin yang bisa registrasi IP.\n\n💸 *Sewa Script PGEtunnel* hanya *Rp8.000/bulan*.`, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [[{ text: '💬 Hubungi Admin', url: 'https://t.me/JesVpnt' }]]
        }
      });
    }
    return bot.sendMessage(chatId, '📝 Masukkan data registrasi IP VPS:\n\n`nama|ip|expired`\n\nContoh:\n`jesvpn|157.42.172.9|1` (1 hari)', {
      parse_mode: 'Markdown'
    });
  }

  // === Tombol Registrasi Trial ===
  if (data === 'trial_ip') {
    if (userId === adminId) {
      return bot.sendMessage(chatId, '⚠️ Admin tidak bisa mendaftar IP trial.');
    }
    return bot.sendMessage(chatId, '🧪 Masukkan *data IP trial*:\n\nFormat:\n`nama|ip`\n\nContoh:\n`trial|157.42.1.1`', {
      parse_mode: 'Markdown'
    });
  }

  // === Tombol Hapus IP (Berdasarkan nama) ===
  if (data === 'delete_ip_entry') {
    if (userId !== adminId) return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menghapus IP VPS.');
    return bot.sendMessage(chatId, '🗑 Masukkan *nama* yang ingin dihapus\n\nContoh:\n`jesvpn`', {
      parse_mode: 'Markdown'
    });
  }

  // === Tombol Hapus Semua IP ===
  if (data === 'delete_all_ips') {
    if (userId !== adminId) return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menghapus semua IP.');

    try {
      const getRes = await axios.get(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      const sha = getRes.data.sha;
      const kosong = Buffer.from('').toString('base64');

      await axios.put(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        message: `Hapus semua IP VPS`,
        content: kosong,
        sha,
        branch: BRANCH
      }, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      bot.sendMessage(chatId, '✅ Semua IP VPS berhasil dihapus!');
    } catch (err) {
      console.error('❌ Gagal hapus semua IP:', err.response?.data || err.message);
      bot.sendMessage(chatId, '❌ Gagal hapus semua IP.');
    }
  }

  // === Tombol List IP ===
  if (data === 'list_ip') {
    if (userId !== adminId) return bot.sendMessage(chatId, '❌ Hanya admin yang bisa melihat daftar IP.');

    try {
      const getRes = await axios.get(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      const content = Buffer.from(getRes.data.content, 'base64').toString('utf-8');
      const lines = content.split('\n').filter(line => line.startsWith('###'));

      if (lines.length === 0) return bot.sendMessage(chatId, '📋 Belum ada data IP VPS yang terdaftar.');

      const listText = lines.map((line, i) => `${i + 1}. ${line.replace('### ', '')}`).join('\n');

      return bot.sendMessage(chatId, `📋 *List IP VPS Yang Terdaftar:*\n\n\`\`\`\n${listText}\n\`\`\``, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [[{ text: '🔙 Kembali', callback_data: 'back_to_menu' }]]
        }
      });
    } catch (err) {
      console.error('❌ Gagal ambil list IP:', err.response?.data || err.message);
      bot.sendMessage(chatId, '❌ Gagal mengambil daftar IP dari GitHub.');
    }
  }

  // === Tombol Kembali/Menu Utama ===
  if (data === 'start_pointing' || data === 'back_to_menu') {
    return showStartMenu(chatId, query.from);
  }
});

// ==========================================================
// ✅ 3. HANDLER PESAN MASUK (MESSAGE TEXT)
// ==========================================================
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
  const userId = msg.from.id;

  // === REGISTRASI IP TRIAL ===
  if (userState[userId] === 'trial_ip' && typeof text === 'string' && text.includes('|')) {
    const [name, ip] = text.split('|').map(s => s.trim());
    if (!name || !ip) return bot.sendMessage(chatId, '❌ Format salah. Contoh `nama|ip`', { parse_mode: 'Markdown' });

    const expiredDate = dayjs().add(1, 'day').format('YYYY-MM-DD');
    const newLine = `### ${name} ${expiredDate} ${ip}`;

    try {
      const getRes = await axios.get(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      const sha = getRes.data.sha;
      const oldContent = Buffer.from(getRes.data.content, 'base64').toString('utf-8');
      const newContent = [newLine, oldContent].join('\n');
      const encoded = Buffer.from(newContent).toString('base64');

      await axios.put(
        `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`,
        {
          message: `Trial ${name} expired ${expiredDate}`,
          content: encoded,
          sha,
          branch: BRANCH
        },
        { headers: { Authorization: `token ${GITHUB_TOKEN}` } }
      );

      const trialCmd = `
🧪 *IP Trial berhasil didaftarkan:*

👤 *Nama:* \`\`\`${name}\`\`\`
🗓️ *Expired:* \`\`\`${expiredDate}\`\`\`
🌐 *IP Tujuan:* \`\`\`${ip}\`\`\`

📥 *Instalasi Script Trial 1 Hari:*
\`\`\`bash
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl unzip && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/script-vpn-premium/vip/main/setup-main.sh && chmod +x setup-main.sh && sed -i -e 's/\r$//' setup-main.sh && screen -S setupku ./setup-main.sh
\`\`\`
`;
      await bot.sendMessage(chatId, trialCmd, { parse_mode: 'Markdown' });
      userState[userId] = null;

    } catch (err) {
      console.error('❌ Gagal push Trial IP:', err.response?.data || err.message);
      bot.sendMessage(chatId, '❌ Gagal push ke GitHub: ' + (err.response?.data?.message || err.message));
    }

    return;
  }

  // === REGISTRASI IP PREMIUM ===
  if (userState[userId] === 'regist_ip' && typeof text === 'string' && text.includes('|')) {
    const [name, ip, expiredStr] = text.split('|').map(s => s.trim());
    if (!name || !ip || !expiredStr) {
      return bot.sendMessage(chatId, '❌ Format salah. Contoh `nama|ip|expired`', { parse_mode: 'Markdown' });
    }

    const expiredDate = dayjs().add(parseInt(expiredStr), 'day').format('YYYY-MM-DD');
    const newLine = `### ${name} ${expiredDate} ${ip}`;

    try {
      const getRes = await axios.get(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      const sha = getRes.data.sha;
      const oldContent = Buffer.from(getRes.data.content, 'base64').toString('utf-8');
      const newContent = [newLine, oldContent].join('\n');
      const encoded = Buffer.from(newContent).toString('base64');

      await axios.put(
        `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`,
        {
          message: `Tambah ${name} expired ${expiredDate}`,
          content: encoded,
          sha,
          branch: BRANCH
        },
        { headers: { Authorization: `token ${GITHUB_TOKEN}` } }
      );

      const installCmd = `
✅ *IP berhasil diregistrasi:*

👤 *Nama:* \`\`\`${name}\`\`\`
🗓️ *Expired:* \`\`\`${expiredDate}\`\`\`
🌐 *IP Tujuan:* \`\`\`${ip}\`\`\`

📥 *Instalasi Script Pgetunnel Premium:*
\`\`\`bash
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl unzip && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/script-vpn-premium/vip/main/setup-main.sh && chmod +x setup-main.sh && sed -i -e 's/\r$//' setup-main.sh && screen -S setupku ./setup-main.sh
\`\`\`
`;
      await bot.sendMessage(chatId, installCmd, { parse_mode: 'Markdown' });
      userState[userId] = null;

    } catch (err) {
      console.error('❌ Gagal push ke GitHub:', err.response?.data || err.message);
      bot.sendMessage(chatId, '❌ Gagal push ke GitHub: ' + (err.response?.data?.message || err.message));
    }

    return;
  }

  // === HAPUS IP BERDASARKAN NAMA (state mode) ===
  if (userState[userId] === 'delete_ip_entry' && typeof text === 'string' && !text.includes('|')) {
    const targetName = text.trim().toLowerCase();

    try {
      const getRes = await axios.get(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      const sha = getRes.data.sha;
      const content = Buffer.from(getRes.data.content, 'base64').toString('utf-8');

      const filtered = content
        .split('\n')
        .filter(line => !line.toLowerCase().startsWith(`### ${targetName} `))
        .join('\n');

      const encoded = Buffer.from(filtered).toString('base64');

      if (content === filtered) {
        return bot.sendMessage(chatId, `❌ Tidak ditemukan entri dengan nama: \`${targetName}\``, { parse_mode: 'Markdown' });
      }

      await axios.put(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
        message: `Hapus IP ${targetName}`,
        content: encoded,
        sha,
        branch: BRANCH
      }, {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      });

      bot.sendMessage(chatId, `✅ IP atas nama \`${targetName}\` berhasil dihapus.`, { parse_mode: 'Markdown' });
      userState[userId] = null;

    } catch (err) {
      console.error('❌ Gagal hapus entri IP:', err.response?.data || err.message);
      bot.sendMessage(chatId, '❌ Gagal menghapus IP dari GitHub.');
    }
  }
});

// ==========================================================
// ✅ 4. FUNGSI AUTO HAPUS IP EXPIRED
// ==========================================================
async function hapusIPExpired() {
  try {
    const res = await axios.get(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
      headers: { Authorization: `token ${GITHUB_TOKEN}` }
    });

    const sha = res.data.sha;
    const content = Buffer.from(res.data.content, 'base64').toString('utf-8');

    const today = dayjs().format('YYYY-MM-DD');

    const filteredLines = content
      .split('\n')
      .filter(line => {
        if (!line.startsWith('###')) return true;
        const parts = line.split(' ');
        const expiredDate = parts[2];
        return dayjs(expiredDate).isAfter(today);
      });

    const newContent = filteredLines.join('\n');
    if (newContent === content) return;

    const encoded = Buffer.from(newContent).toString('base64');

    await axios.put(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
      message: 'Otomatis hapus IP expired',
      content: encoded,
      sha,
      branch: BRANCH
    }, {
      headers: { Authorization: `token ${GITHUB_TOKEN}` }
    });

    console.log('✅ IP expired berhasil dihapus otomatis.');
  } catch (err) {
    console.error('❌ Gagal hapus IP expired:', err.response?.data || err.message);
  }
}

hapusIPExpired();
setInterval(hapusIPExpired, 3600000);
// ==========================================================
// ✅ Callback Query Handler
// ==========================================================
bot.on('callback_query', async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;

  if (data === 'donate') {
    delete userState[chatId]; // reset state jika ada
    userState[chatId] = { step: 'waiting_for_amount' };

    await bot.sendPhoto(chatId, 'https://files.catbox.moe/207t9m.jpg', {
      caption: `↪️ *Scan QRIS di atas untuk melakukan donasi.*

💬 Setelah transfer, *masukkan jumlah donasi*  
🙏 yang telah kamu kirim (contoh: \`10000\`)

🔄 Jika tidak jadi, wajib batal agar bot tidak error.`,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '❌ Batal', callback_data: 'cancel_donation' }]
        ]
      }
    });
  }

  // Jika user menekan tombol batal
  if (data === 'cancel_donation') {
    delete userState[chatId];
    await bot.sendMessage(chatId, '❌ Proses donasi telah dibatalkan.');
  }
});

// Handle perintah manual /batal (opsional tetap disediakan)
bot.onText(/\/batal/, async (msg) => {
  const chatId = msg.chat.id;
  if (userState[chatId]) {
    delete userState[chatId];
    return bot.sendMessage(chatId, '❌ Proses donasi telah dibatalkan.');
  }
});

// Handle semua pesan dari user
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const state = userState[chatId];

  if (msg.from.is_bot) return;
  if (!state) return;

  // Tahap input jumlah donasi
  if (state.step === 'waiting_for_amount') {
    if (!msg.text || isNaN(msg.text.replace(/\D/g, ''))) {
      return bot.sendMessage(chatId, '⚠️ Masukkan jumlah angka donasi. Contoh: `10000` atau `10.000`', {
        parse_mode: 'Markdown'
      });
    }

    const cleanedAmount = msg.text.replace(/[^\d]/g, '');

    userState[chatId] = {
      step: 'waiting_for_photo',
      amount: cleanedAmount
    };

    if (userState[chatId] && userState[chatId].step === 'waiting_for_photo') {
      return bot.sendMessage(chatId, '📸 *Kirim bukti transfer berupa gambar (screenshot)*', {
        parse_mode: 'Markdown'
      });
    }

    return;
  }

  // Tahap kirim bukti transfer (foto)
  if (state.step === 'waiting_for_photo') {
    if (!msg.photo) {
      return bot.sendMessage(chatId, '⚠️ Harap kirim *gambar bukti transfer*. Jika batal, tekan tombol Batal atau ketik /batal.', {
        parse_mode: 'Markdown'
      });
    }

    const amount = state.amount;
    const photo = msg.photo[msg.photo.length - 1].file_id;
    const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;

    await bot.sendPhoto(groupNotifId, photo, {
      caption: `🎉 *Donasi Baru Masuk!*

💸 Jumlah: Rp${amount}
👤 Dari: ${username}`,
      parse_mode: 'Markdown'
    });

    await bot.sendMessage(chatId, '✅ *Terima kasih!* Donasimu sudah kami terima.\n🙏 Semoga berkah dan bermanfaat.', {
      parse_mode: 'Markdown'
    });

    delete userState[chatId];
  }
});
// ==========================================================
// ✅ CALLBACK HANDLER
// ==========================================================
bot.on('callback_query', async (query) => {
  const msg = query.message;
  const data = query.data;
  const chatId = msg.chat.id;
  const userId = query.from.id;

  if (data === 'check_joined') {
    const isNowJoined = await isUserJoinedChannel(userId);
    if (isNowJoined) {
      await bot.deleteMessage(chatId, msg.message_id);
      return bot.sendMessage(chatId, '✅ Kamu sudah join! Ketik /start untuk mulai.', { parse_mode: 'Markdown' });
    } else {
      return bot.answerCallbackQuery({
        callback_query_id: query.id,
        text: '❌ Kamu belum join channel. Ayo join dulu ya!',
        show_alert: true
      });
    }
  }

  if (data === 'login_cf') {
    userState[userId] = { step: 'awaiting_email', invalid: false };
    return bot.sendMessage(chatId, '📧 *Masukkan Email Cloudflare Anda:*', { parse_mode: 'Markdown' });
  }

  if (data === 'my_cf_account') {
  const cfAccounts = JSON.parse(fs.readFileSync(cfAccountsFile));
  const cf = cfAccounts[userId];
  if (!cf) return bot.sendMessage(chatId, '❌ Anda belum login ke akun Cloudflare.');

  return bot.sendMessage(chatId,
    `🔐 *Akun Cloudflare Anda:*\n\n📧 *Email:* \`${cf.email}\`\n🔑 *API Key:* \`${cf.apiKey}\``,
    { parse_mode: 'Markdown' }
  );
}

  if (data === 'logout_cf') {
    const cfAccounts = JSON.parse(fs.readFileSync(cfAccountsFile));
    if (cfAccounts[userId]) {
      delete cfAccounts[userId];
      saveJSON(cfAccountsFile, cfAccounts);
      return bot.sendMessage(chatId, '✅ Akun Cloudflare berhasil dihapus.');
    } else {
      return bot.sendMessage(chatId, '❌ Tidak ditemukan akun untuk dihapus.');
    }
  }

  if (data === 'start_pointing') {
    const cfAccounts = JSON.parse(fs.readFileSync(cfAccountsFile));
    const account = cfAccounts[userId];
    if (!account) return bot.sendMessage(chatId, '❌ Anda belum login ke akun Cloudflare.');

    try {
      const zones = (await axios.get('https://api.cloudflare.com/client/v4/zones', {
        headers: {
          'X-Auth-Email': account.email,
          'X-Auth-Key': account.apiKey,
          'Content-Type': 'application/json'
        }
      })).data.result;

      if (!zones.length) return bot.sendMessage(chatId, '❌ Tidak ada domain di akun Cloudflare Anda.');

      const buttons = zones.map(z => [{ text: z.name, callback_data: `select_domain_${z.id}` }]);
      return bot.sendMessage(chatId, '🌐 Pilih domain yang ingin digunakan:', {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: buttons }
      });
    } catch {
      return bot.sendMessage(chatId, '❌ Gagal mengambil daftar domain.');
    }
  }

  if (data.startsWith('select_domain_')) {
    const zoneId = data.replace('select_domain_', '');
    const cfAccounts = JSON.parse(fs.readFileSync(cfAccountsFile));
    const account = cfAccounts[userId];
    if (!account) return;

    try {
      const zoneInfo = (await axios.get(`https://api.cloudflare.com/client/v4/zones/${zoneId}`, {
        headers: {
          'X-Auth-Email': account.email,
          'X-Auth-Key': account.apiKey,
          'Content-Type': 'application/json'
        }
      })).data.result;

      cfAccounts[userId].zone_id = zoneId;
      saveJSON(cfAccountsFile, cfAccounts);

      bot.sendMessage(chatId, '📝 *Masukkan subdomain:*\n✅ Contoh: `vpn`', { parse_mode: 'Markdown' });

      bot.once('message', (subMsg) => {
        const sub = subMsg.text.trim().toLowerCase();
        if (!/^[a-z0-9-]+$/.test(sub)) return bot.sendMessage(chatId, '❌ Subdomain tidak valid.');

        bot.sendMessage(chatId, '📥 Kirim *IP Tujuan*:\n✅ Contoh: `1.2.3.4`', { parse_mode: 'Markdown' });

        bot.once('message', async (ipMsg) => {
          const ip = ipMsg.text.trim();
          if (!/^\d+\.\d+\.\d+\.\d+$/.test(ip)) return bot.sendMessage(chatId, '❌ IP tidak valid.');

          const full = `${sub}.${zoneInfo.name}`;
          const headers = {
            'X-Auth-Email': account.email,
            'X-Auth-Key': account.apiKey,
            'Content-Type': 'application/json'
          };

          try {
            const check = await axios.get(
              `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records?type=A&name=${full}`, { headers });
            const existing = check.data.result[0];

            if (existing) {
              if (existing.content === ip) {
                return bot.sendMessage(chatId, `⚠️ \`${full}\` sudah mengarah ke IP yang sama.`, { parse_mode: 'Markdown' });
              }
              await axios.put(
                `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records/${existing.id}`,
                { type: "A", name: full, content: ip, ttl: 120, proxied: false }, { headers });

              return bot.sendMessage(chatId, `♻️ *IP diperbarui!*\n\n🌐 \`${full}\`\n📍 IP: \`${ip}\``, { parse_mode: 'Markdown' });
            }

            await axios.post(
              `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`,
              { type: "A", name: full, content: ip, ttl: 120, proxied: false }, { headers });

            return bot.sendMessage(chatId, `✅ *Pointing berhasil!*\n\n🌐 \`${full}\`\n📍 IP: \`${ip}\``, { parse_mode: 'Markdown' });

          } catch (err) {
            const msg = err.response?.data?.errors?.[0]?.message || err.message;
            return bot.sendMessage(chatId, `❌ Error:\n${msg}`);
          }
        });
      });
    } catch {
      return bot.sendMessage(chatId, '❌ Gagal mengambil info domain.');
    }
  }
});

// Message handler
bot.on('message', async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;
  const text = msg.text?.trim();
  const state = userState[userId];

  if (state?.step === 'awaiting_email') {
    userState[userId] = { step: 'awaiting_api_key', email: text, invalid: false };
    return bot.sendMessage(chatId, '🔐 *Masukkan API Key Cloudflare Anda:*', { parse_mode: 'Markdown' });
  }

  if (state?.step === 'awaiting_api_key') {
    const email = state.email;
    const apiKey = text;

    try {
      const res = await axios.get('https://api.cloudflare.com/client/v4/zones', {
        headers: {
          'X-Auth-Email': email,
          'X-Auth-Key': apiKey,
          'Content-Type': 'application/json'
        }
      });

      if (res.data.success && res.data.result.length > 0) {
        const firstZone = res.data.result[0];
        const cfAccounts = fs.existsSync(cfAccountsFile) ? JSON.parse(fs.readFileSync(cfAccountsFile)) : {};
        cfAccounts[userId] = { email, apiKey, zone_id: firstZone.id };
        saveJSON(cfAccountsFile, cfAccounts);

        userState[userId] = null;
        return bot.sendMessage(chatId, `✅ *Login berhasil!*\n\n🌐 Domain default: \`${firstZone.name}\``, { parse_mode: 'Markdown' });
      } else {
        return bot.sendMessage(chatId, `❌ Tidak ada domain ditemukan di akun Anda.`, { parse_mode: 'Markdown' });
      }
    } catch {
      if (!state.invalid) {
        userState[userId].invalid = true;
        return bot.sendMessage(chatId, `❌ *Email atau API Key salah.*

🔐 *Gunakan Global API Key*
👉 https://dash.cloudflare.com/profile/api-tokens`, {
          parse_mode: 'Markdown',
          disable_web_page_preview: true
        });
      }
    }
  }
});

// Broadcast ke semua user
let isBroadcastMode = false;

bot.onText(/\/broadcast$/, (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (userId !== adminId) {
    return bot.sendMessage(chatId, '🚫 Maaf, fitur ini hanya untuk *Admin*.', { parse_mode: 'Markdown' });
  }

  isBroadcastMode = true;
  return bot.sendMessage(chatId, '✉️ Kirim pesan *teks / foto / dokumen* untuk broadcast ke semua user:', { parse_mode: 'Markdown' });
});

bot.on('message', async (msg) => {
  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (!isBroadcastMode || userId !== adminId || msg.text?.startsWith('/')) return;

  isBroadcastMode = false;
  const users = fs.existsSync(userFile) ? JSON.parse(fs.readFileSync(userFile)) : [];

  let sukses = 0, gagal = 0;

  const kirimKeSemua = async (sendFunc) => {
    for (let i = 0; i < users.length; i += 30) {
      const batch = users.slice(i, i + 30);
      const hasil = await Promise.allSettled(batch.map(u => sendFunc(u.id)));
      sukses += hasil.filter(h => h.status === 'fulfilled').length;
      gagal += hasil.filter(h => h.status === 'rejected').length;
      await new Promise(res => setTimeout(res, 1500));
    }
  };

  // Kirim berdasarkan jenis konten
  if (msg.photo) {
    const photoId = msg.photo[msg.photo.length - 1].file_id;
    await kirimKeSemua((id) => bot.sendPhoto(id, photoId, { caption: msg.caption || '' }));
  } else if (msg.document) {
    const docId = msg.document.file_id;
    await kirimKeSemua((id) => bot.sendDocument(id, docId, { caption: msg.caption || '' }));
  } else if (msg.text) {
    const text = msg.text;
    await kirimKeSemua((id) => bot.sendMessage(id, text, { parse_mode: 'Markdown' }));
  } else {
    return bot.sendMessage(chatId, '⚠️ Jenis pesan belum didukung untuk broadcast.');
  }

  return bot.sendMessage(chatId, `✅ Broadcast selesai.\n📬 Berhasil: ${sukses}\n❌ Gagal: ${gagal}`);
});

// ==========================================================
// ✅ 7. AUTO BACKUP TIAP 5 JAM
// ==========================================================
setInterval(() => backupFile(userFile, '🕒 [Auto Backup] File users:', adminId), 18000000);
setInterval(() => backupFile(domainFile, '🕒 [Auto Backup] File accounts:', adminId), 18000000);